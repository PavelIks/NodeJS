module.export = {
		entry: './app.js',
		output: {
			filename: './bundle.js',
			library: 'myApp'
		}
};